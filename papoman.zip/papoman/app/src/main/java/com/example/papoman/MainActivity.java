package com.example.papoman;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText edcaja1,edtcaja2;

    TextView textResultado;

    Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        edcaja1=findViewById(R.id.edtcaja1);
        edtcaja2=findViewById(R.id.edtcaja2);
        textResultado=findViewById(R.id.textResultado);
        btnCalcular=findViewById(R.id.btnCalcular);


    }
}